// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
public class Bishop {private int row;
    private int col;
    private boolean isBlack;
    public Bishop(int row, int col, boolean isBlack){ // create a constructor of the Bishop class;
        this.row =row;
        this.col=col;
        this.isBlack = isBlack;
    }
    public boolean isMoveLegal(Board board, int endRow, int endCol){
        if(board.verifyDiagonal(row,col,endRow,endCol)&&board.verifySourceAndDestination(row,col,endRow,endCol,isBlack)) {
            return true;
        }else{
            return false;
        }
    }//check whether the Bishop can move diagonal and whether it can move legal or not;
}


