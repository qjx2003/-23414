// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
public class King {
    private int row;
    private int col;
    private boolean isBlack;

    public King(int row, int col, boolean isBlack) { //create a constructor of King class;
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        if (board.verifySourceAndDestination(row, col, endRow, endCol, isBlack)) {
            if (board.verifyAdjacent(row, col, endRow, endCol)) {
                return true;
            }
        }
        return false;
    }//check whether the king can move adjacent and whether it can move legal or not;
}



