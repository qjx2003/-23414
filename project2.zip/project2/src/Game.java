// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
import java.util.Scanner;
public class Game {
    public static void main(String[] arg) {
        Board board = new Board();// create a new board;
        Fen.load("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", board);
        boolean gameIsOver = false;
        while (!gameIsOver) {
            if(board.getIsBlack()){  // check who turns it is(black or white);
                System.out.println("It is black's turn\n");
            }else{
                System.out.println("It is white's turn\n");
            }
            System.out.println(board);
            System.out.println("What is your move(format: [startRow] [startCol] [endRow] [endCol])?");
            Scanner scanner = new Scanner(System.in);
            String s = scanner.nextLine();
            String[] array = s.split(" ");//use the space to split the user input number;
             while(board.movePiece(Integer.parseInt(array[0]), Integer.parseInt(array[1]), Integer.parseInt(array[2]), Integer.parseInt(array[3]))!=true){
                 System.out.println("Invaild move, try again!");
                 System.out.println("What is your move(format: [startRow] [startCol] [endRow] [endCol])?");
                 s = scanner.nextLine();
                 array = s.split(" ");
             }
             // check if the movePiece is true, if it is not true, let the user input another number;
            // Integer.parseInt() is a method that change a string array to a integer;
            Piece newPiece = board.getPiece(Integer.parseInt(array[2]), Integer.parseInt(array[3])); // get a new piece on the board which position is endRow and endCol;
            if(Integer.parseInt(array[2])==0||Integer.parseInt(array[2])==7){
            newPiece.promotePawn(Integer.parseInt(array[2]),newPiece.getIsBlack());
            } // check whether the pawn is on the fist row or the end row;
            if (board.isGameOver()) {
                gameIsOver = true;
                System.out.println("Game is over!"); // check whether the game is over;
            }
        }
    }
}
