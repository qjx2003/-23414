// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
public class Rook {
    private int row;
    private int col;
    private boolean isBlack;
    public Rook(int row, int col, boolean isBlack){ //create a constructor of Rook class;
        this.row =row;
        this.col=col;
        this.isBlack = isBlack;
    }
    public boolean isMoveLegal(Board board, int endRow, int endCol){
        if((board.verifyHorizontal(row,col,endRow,endCol)||board.verifyVertical(row,col,endRow,endCol))&&board.verifySourceAndDestination(row,col,endRow,endCol,isBlack)) {
            return true;
        }else{
            return false;
        }
    }//check whether the rook can move horizontal or vertical and whether it can move legal or not;
}

