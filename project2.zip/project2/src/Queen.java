// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
public class Queen {
    private int row;
    private int col;
    private boolean isBlack;
    public Queen(int row, int col, boolean isBlack){ //create a constructor of Queen class;
        this.row =row;
        this.col=col;
        this.isBlack = isBlack;
    }
    public boolean isMoveLegal(Board board, int endRow, int endCol){
        if((board.verifyVertical(row,col,endRow,endCol)||board.verifyHorizontal(row,col,endRow,endCol)||board.verifyDiagonal(row,col,endRow,endCol))&&board.verifySourceAndDestination(row,col,endRow,endCol,isBlack)) {
            return true;
        }else{
            return false;
        }
    }//check whether the queen can move horizontal or vertical or diagonal and whether it can move legal or not;
}
