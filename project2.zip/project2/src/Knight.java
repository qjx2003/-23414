// Written by Dongnan Liu liu02385 and Keyu Zhu zhu00728;
public class Knight {
    private int row;
    private int col;
    private boolean isBlack;

    public Knight(int row, int col, boolean isBlack) { //create a constructor of Knight class;
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        if (board.verifySourceAndDestination(row, col, endRow, endCol, isBlack)) {
            if ((Math.abs(this.row - endRow) == 2 && Math.abs(this.col - endCol) == 1) || (Math.abs(this.row - endRow) == 1 && Math.abs(this.col - endCol) == 2)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    } // First check whether it can move legal or not, second check whether it has a route like "L"(first move one row and two col or two row and one col);
}