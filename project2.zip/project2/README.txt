﻿Group members’ names and x500s
Dongnan Liu: liu02385, keyu zhu: zhu00728 


• Contributions of each partner (if working with a partner)
We communicate with each other 
Game.java, Piece.java, Board.java, rook.java (Dongnan Liu and keyu zhu)
King.java, Queen.java (keyu zhu)
Knight.java, Bishop.java (Dongnan Liu)


• How to compile and run your program 
We use Intellij to compile and run our program. 
Everytime we click the green run button on the right top corner to compile and run our program. 


• Any assumptions
First, move the white piece, then move the black piece. everytime we move the piece, we should make the user input the startRow, startCol, endRow, endCol. If the movement is correct, continue, if not, the computer will print, “try again”, and make the user enter the number again. finally, if one side king capture another king, the game is over.


• Additional features that you implemented (if applicable)
 
• Any known bugs or defects in the program 
The output of the checkerboard may not be the same on different types of computers.


In the Piece.java, we do not use the “row” in the promotePawn method, but we check the row 0 and row 7 in the game.java. Our implementation is correct. When we find this problem, there is no office hour.


• Any outside sources (aside from course resources) consulted for ideas used in the project, in the format: 
– switch, case in game.java: google
– the logic of game.java: TA
– In board.java, the logic of diagonal, vertical, horizontal: TA


“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus.” 
Dongnan Liu
keyu zhu